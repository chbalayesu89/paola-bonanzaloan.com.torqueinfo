declare module "@salesforce/apex/PaymentHistoryHelper.getSchedule" {
  export default function getSchedule(param: {recordId: any}): Promise<any>;
}
