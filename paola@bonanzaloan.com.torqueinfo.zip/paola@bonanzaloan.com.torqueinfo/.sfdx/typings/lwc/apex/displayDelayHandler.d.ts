declare module "@salesforce/apex/displayDelayHandler.getdisplayWrapper" {
  export default function getdisplayWrapper(param: {recordId: any}): Promise<any>;
}
