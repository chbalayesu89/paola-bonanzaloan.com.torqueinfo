declare module "@salesforce/apex/opportunity_getpayment_lwc_controller.getPaymentDetails" {
  export default function getPaymentDetails(param: {opportunityId: any}): Promise<any>;
}
declare module "@salesforce/apex/opportunity_getpayment_lwc_controller.savePaymentHistory" {
  export default function savePaymentHistory(param: {strData: any}): Promise<any>;
}
