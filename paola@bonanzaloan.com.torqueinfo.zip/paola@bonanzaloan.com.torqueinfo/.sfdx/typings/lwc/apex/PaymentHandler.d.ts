declare module "@salesforce/apex/PaymentHandler.fetchPayments" {
  export default function fetchPayments(param: {recordId: any}): Promise<any>;
}
