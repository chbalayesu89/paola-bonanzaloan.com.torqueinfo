declare module "@salesforce/apex/account_details_lwc_controller.getAccountDetails" {
  export default function getAccountDetails(param: {opportunityId: any, sort_direction: any, fromdate: any, todate: any}): Promise<any>;
}
declare module "@salesforce/apex/account_details_lwc_controller.savePaymentHistory" {
  export default function savePaymentHistory(param: {strData: any}): Promise<any>;
}
declare module "@salesforce/apex/account_details_lwc_controller.saveRepoDetails" {
  export default function saveRepoDetails(param: {strData: any}): Promise<any>;
}
