declare module "@salesforce/apex/DeskaDealLightningController.VINexists" {
  export default function VINexists(param: {VIN: any}): Promise<any>;
}
declare module "@salesforce/apex/DeskaDealLightningController.doClientSearch" {
  export default function doClientSearch(param: {firstname: any, lastname: any, phone: any}): Promise<any>;
}
declare module "@salesforce/apex/DeskaDealLightningController.updateLead" {
  export default function updateLead(param: {leadID: any, loanAmount: any, term: any, totalInterest: any, APR: any, monthlyEMI: any}): Promise<any>;
}
declare module "@salesforce/apex/DeskaDealLightningController.searchStoreLead" {
  export default function searchStoreLead(param: {isInPermissionSet: any, firstname: any, lastname: any, phone: any, frequency: any, loanAmt: any, Fees: any, months: any, rate: any, IPaid: any, Emi: any, duedate: any}): Promise<any>;
}
declare module "@salesforce/apex/DeskaDealLightningController.saveAccountOpportunityPopupData" {
  export default function saveAccountOpportunityPopupData(param: {accountObj: any, opportunityObj: any}): Promise<any>;
}
