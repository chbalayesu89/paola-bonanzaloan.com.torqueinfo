declare module "@salesforce/apex/accountOpportunityHomeScreenController.saveAccountOpportunity" {
  export default function saveAccountOpportunity(param: {accountObj: any, opportunityObj: any}): Promise<any>;
}
