({
    doInit : function(component, event, helper) {
        var recID = component.get("v.recordId");
        var action = component.get("c.getdisplayWrapper");
        action.setParams({
            recordId: recID
        });
        action.setCallback(this, function(response){
            var data = response.getReturnValue();
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.delayeWrapperProperty", data);
            }
            $A.get("e.force:refreshView").fire();
            
        });
        $A.enqueueAction(action);
    }
    
})