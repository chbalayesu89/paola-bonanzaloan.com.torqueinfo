({
	printdocument : function(component, event, helper) {
        let print_doc_url='/apex/APXTConga4__Conga_Composer?SolMgr=1'+
		'&serverUrl={!API.Partner_Server_URL_520}'+
		'&Id='+component.get("v.recordId")+
		'&TemplateId=0T_007UAA470539&DefaultPDF=1&DS7=3&AC0=1';
		window.open(print_doc_url);
	},
    cancel : function(component, event, helper) {
		var dismissActionPanel = $A.get("e.force:closeQuickAction");
        dismissActionPanel.fire();
	},
    savedocument: function(component, event, helper) {
        let print_doc_url='/apex/APXTConga4__Conga_Composer?SolMgr=1'+
		'&serverUrl={!API.Partner_Server_URL_520}'+
		'&Id='+component.get("v.recordId")+
		'&TemplateId=0T_007UAA470539&DefaultPDF=1&DS7=1';
		window.open(print_doc_url);
	},
})