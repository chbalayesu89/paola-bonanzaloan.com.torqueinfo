({
    doInit: function(component, event, helper) {
        console.log('doInit');
        var recID = component.get("v.recordId");
        var action = component.get("c.getSchedule");
        action.setParams({
            recordId: recID
        });
        action.setCallback(this, function(response){
            var state = response.getState();
            
            if(state === "SUCCESS"){
                var data = response.getReturnValue();
                component.set("v.dataWrapper",data);
                console.log('v.dataWrapper'+component.get('v.dataWrapper'));
              //debugger;
                var startDate = new Date(); 
                var endDate = new Date(component.get('v.dataWrapper.paymentDueDate'));
                var days = (endDate-startDate)/8.64e7;
                //days = Math.abs(days);
                var lateFees= 0.00;
                if(days >= 5 && days <=35){
                    lateFees=25.0;
                }
                else if(days >=35 && days <=70){
                    lateFees= 50.0;
                }
                
                console.log( component.get('v.dataWrapper.method') );
                
                var evt = $A.get("e.force:createRecord");
                evt.setParams({ 
                    'entityApiName':'Payment_History__c',
                    'defaultFieldValues': {
                        'Effective_Date__c':$A.localizationService.formatDate(new Date(), "YYYY-MM-DD"),
                        'Client_Name__c':component.get('v.recordId'),
                        'Due_Date__c': $A.localizationService.formatDate(component.get('v.dataWrapper.paymentDueDate'), "YYYY-MM-DD"),
                        'Total_Due__c':component.get('v.dataWrapper.paymentEMI'),
                        'Principal_Due__c':component.get('v.dataWrapper.paymentPrincipal'),
                        'Interest_Due__c':component.get('v.dataWrapper.paymentInterest'),
                        'Term__c' :component.get('v.dataWrapper.term'),
                        'Total_Due_Month__c' :component.get('v.dataWrapper.paymentDueInTerm'),
                        'Method__c' :component.get('v.dataWrapper.method'),
                        'Total_Paid__c': component.get('v.dataWrapper.totalPaid')
                        //'Status__c':component.get('v.dataWrapper.status')
                    }
                });
                evt.fire();
                
            }else{
                var errorMsg = action.getError()[0].message;
            console.log(errorMsg);
            var toastEvent = $A.get("e.force:showToast");
            toastEvent.setParams({
                title: 'Error',
                type: 'error',
                message: errorMsg
            });
            toastEvent.fire(); 
            }      
            
        });
        $A.enqueueAction(action);
    }
    
    /*
      
                var startDate = new Date(); 
                var endDate = new Date(component.get('v.dataWrapper.Due_Date__c'));
                var days = (endDate-startDate)/8.64e7;
                days = Math.abs(days);
                var apr = component.get('v.dataWrapper.APR__c');
                var balnce = component.get('v.dataWrapper.Balance_Due__c');
                var lateFees=0;
                var lateFees = (days*apr*balnce)/36500;
                console.log('lateFees '+ lateFees);
     
    */
})