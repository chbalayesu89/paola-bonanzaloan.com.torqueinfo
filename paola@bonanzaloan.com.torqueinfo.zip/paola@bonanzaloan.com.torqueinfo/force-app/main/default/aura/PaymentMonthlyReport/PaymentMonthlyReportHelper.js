({
    fetchPayHelper : function(component, event, helper) {
        component.set('v.mycolumns', [
            {label: 'Date Paid', fieldName: 'Effective_Date__c', type: 'date-local', cellAttributes: { alignment: 'left' }},
            {label: 'Term', fieldName: 'Term__c', type: 'text', cellAttributes:  { alignment: 'left' }},
            {label: 'Total Due', fieldName: 'Total_Due__c', type: 'currency', cellAttributes: { alignment: 'left' }},
            {label: 'Total Paid', fieldName: 'Total_Paid__c', type: 'currency', cellAttributes: { alignment: 'left' }},
            {label: '# Days Delayed', fieldName: 'No_of_day_s_delayed__c', type: 'text ',cellAttributes: { alignment: 'left' }},
            {label: 'Status', fieldName: 'Status__c', type: 'text ',cellAttributes: { alignment: 'left' }}
        ]);
        var action = component.get("c.fetchPayments");
        action.setParams({
            recordId : component.get('v.recordId'),
        });
        action.setCallback(this, function(response){
            debugger;
            var state = response.getState();
            if (state === "SUCCESS") {
                component.set("v.payList", response.getReturnValue());
            }
        });
        $A.enqueueAction(action);
    }
   
})