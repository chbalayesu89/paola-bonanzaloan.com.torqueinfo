({
    fetchPayment : function(component, event, helper) {
        helper.fetchPayHelper(component, event, helper);
    }
})