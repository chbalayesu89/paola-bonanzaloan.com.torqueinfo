import { LightningElement,api,track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import modal from "@salesforce/resourceUrl/custommodal";
import { CloseActionScreenEvent } from "lightning/actions";
import { loadStyle } from "lightning/platformResourceLoader";
import getData from "@salesforce/apex/opportunity_getpayment_lwc_controller.getPaymentDetails";
import savePayment from "@salesforce/apex/opportunity_getpayment_lwc_controller.savePaymentHistory";

export default class Opportunity_getPayment_lwc extends LightningElement {
    @api recordId;
    @track data = [];
    paymentschedulerecord={};
    show_spinner=false;
    @track paymentHistoryModal={
        'sobjectType':'Payment_History__c',
        'Client_Name__c':this.recordId,
        'Payment_Schedule__c':null,
        'EMI_Amount__c':null,
        'Interest_Due__c':null,
        'Principal_Due__c':null,        
        'Late_Fees_Due__c':null,
        'Balance__c':null,
        'Method__c':'',
        'Due_Date__c':null,
        'Total_Paid__c':null,
        'Term__c':null
    };
    recordId_rendered=false;
    connectedCallback() { 
        this.show_spinner=true;       
        console.log('recordId:'+this.recordId);
        loadStyle(this, modal);  
    }
      renderedCallback() {
        if(!this.recordId_rendered &&
             this.recordId!=undefined){
                console.log(this.recordId + ' is provided');
            this.recordId_rendered=true;
            this.retrieveData();             
        } 
      }
      closeAction() {
        this.dispatchEvent(new CloseActionScreenEvent());
      }
      account_condition_picklist_value = 'Date Added';
      payment_schedule_picklist_options=[];
      payment_schedule_picklist_value='Select';
      showCreatePaymentScreen=false;
    /*get paymentschedule_picklist_options() {
        return [
            { label: 'Date Added', value: 'Date Added' },
            { label: 'In Progress', value: 'inProgress' },
            { label: 'Finished', value: 'finished' },
        ];
    }*/

    handleChange(event) {
        this.paymentschedule_picklist_value = event.detail.value;
    }
    show_payment_schedule_picklist=false;

    retrieveData(){       
        this.show_spinner=true; 
        getData({ opportunityId: this.recordId })
            .then(result => {
                console.log('result:' + JSON.stringify(result));                
                this.data = result;      
                this.error = undefined;
                //populate payment schedule picklist
                for(let x of this.data.paymentschedulelist){
                    this.payment_schedule_picklist_options.push({label: x.Name, value: x.Id });
                }
                if(this.payment_schedule_picklist_options.length>0){
                    this.show_payment_schedule_picklist=true;
                }else{
                    this.show_payment_schedule_picklist=false;
                }
                this.show_spinner=false;
                console.log('show_spinner:'+this.show_spinner);
                console.log('show_payment_schedule_picklist:'+this.show_payment_schedule_picklist);
                console.log('showCreatePaymentScreen:'+this.showCreatePaymentScreen);
                console.log('payment_schedule_picklist_options:'+JSON.stringify(this.payment_schedule_picklist_options));
            })
            .catch(error => {
                this.error = error;
                this.data = undefined;
                console.log('error setting default', error);
                const evt = new ShowToastEvent({
                    title: 'ERROR',
                    message: ''+JSON.stringify(error),
                    variant: 'error',
                    mode: 'dismissable'
                });
                this.dispatchEvent(evt);
                this.show_spinner=false;
            });                    
    }
    handleCreatePaymentClick(event){  
        try{      
        console.log('handleCreatePaymentClick');
        console.log('paymentschedule_picklist_value:'+this.paymentschedule_picklist_value);
        if(this.paymentschedule_picklist_value!=undefined){
        let flag=false;
        /*for(let x of this.data.paymenthistorylist){
            if(x.Payment_Schedule__c===this.paymentschedule_picklist_value){
                flag=true;
                break;
            }
        }*/
        if(flag){
            this.showCreatePaymentScreen=false;
            const evt = new ShowToastEvent({
                title: 'Payment Exists',
                message: 'Please select different Payment Schedule',
                variant: 'warning',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
        }else{
            this.paymentHistoryModal.Payment_Schedule__c=this.paymentschedule_picklist_value;
            this.paymentHistoryModal.Client_Name__c=this.recordId;
            
            for(let x of this.data.paymentschedulelist){
                if(x.Id===this.paymentschedule_picklist_value){
                    this.paymentschedulerecord=x;
                    break;
                }
            }
            console.log('paymentschedulerecord:'+JSON.stringify(this.paymentschedulerecord));
            console.log('this.paymentschedulerecord.Emi__c:'+this.paymentschedulerecord.Emi__c);
          //  this.paymentHistoryModal.EMI_Amount__c=this.paymentschedulerecord.Emi__c;
            this.paymentHistoryModal.Interest_Due__c=this.paymentschedulerecord.Interest_Due__c;
            this.paymentHistoryModal.Principal_Due__c=this.paymentschedulerecord.Monthly_Principal_amount__c;
            this.paymentHistoryModal.Balance__c=this.paymentschedulerecord.Balance__c;
            this.paymentHistoryModal.Term__c=this.paymentschedulerecord.Month__c;
            this.paymentHistoryModal.Due_Date__c=this.paymentschedulerecord.Due_Date__c;
            //this.paymentHistoryModal.Total_Paid_Amount__c=this.paymentschedulerecord.Payment_Collected_Rollup__c;
            this.showCreatePaymentScreen=true;
        }
    }else{   
        console.log('Payment Schedule Not Selected'); 
        this.showCreatePaymentScreen=false;  
        const evt = new ShowToastEvent({
            title: 'Payment Schedule Not Selected',
            message: 'Please select Payment Schedule from the dropdown',
            variant: 'warning',
            mode: 'dismissable'
        });
        this.dispatchEvent(evt);        
    }
}catch(err){
    console.log(err.stack);
}
    }
    handleSavePaymentClick(event){    
        console.log('handleSavePaymentClick'); 
        this.show_spinner=true;
        try{
        console.log('strData'+JSON.stringify(this.paymentHistoryModal));
        savePayment({ strData: JSON.stringify(this.paymentHistoryModal)})
        .then(result => {
            console.log('result:' + JSON.stringify(result));                
          //  this.data = result;      
            this.error = undefined;
            this.closeAction();
            const evt = new ShowToastEvent({
                title: 'Success',
                message: 'Record Saved!',
                variant: 'success',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
            
            this.show_spinner=false;
        })
        .catch(error => {
            this.error = error;
            const evt = new ShowToastEvent({
                title: 'ERROR',
                message: ''+JSON.stringify(error),
                variant: 'error',
                mode: 'dismissable'
            });
            this.dispatchEvent(evt);
            this.data = undefined;
            console.log('error setting default', error);
            this.show_spinner=false;
        }); 
    }catch(err){
        console.log('error:'+err.stack);
    }       
    }
    readEMI(event){
        this.paymentHistoryModal.EMI_Amount__c=event.target.value;
    }
    readMethod(event){
        this.paymentHistoryModal.Method__c=event.target.value;
    }
    readPaymentDate(event){
        this.paymentHistoryModal.Effective_Date__c=event.target.value;
    }
    readLateFee(event){
        this.paymentHistoryModal.Late_Fees_Due__c=event.target.value;
    }
}