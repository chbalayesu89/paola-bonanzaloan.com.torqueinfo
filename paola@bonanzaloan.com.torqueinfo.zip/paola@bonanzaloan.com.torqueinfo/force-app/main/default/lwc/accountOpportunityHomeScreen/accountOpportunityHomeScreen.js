import { LightningElement, api, track } from 'lwc';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import saveAccountOppData from "@salesforce/apex/accountOpportunityHomeScreenController.saveAccountOpportunity";

export default class AccountOpportunityHomeScreen extends LightningElement {
    customerObj = {};
    accountObj = {};
    opportunityObj = {};
    showAccountOpportunityDialog = false;
    createaccountWithOpportunity(event) {
        //account details
        this.accountObj.name = this.customerObj.firstName + ' ' + this.customerObj.lastName;
        this.accountObj.phone = this.customerObj.phone;
        //opportunity details
        this.opportunityObj.name = this.customerObj.firstName + ' ' + this.customerObj.lastName;
        this.opportunityObj.phone = this.customerObj.phone;
        this.showAccountOpportunityDialog = true;
    }
    cancelAccountOpportunityDialog(event) {
        this.showAccountOpportunityDialog = false;
    }
    readFirstName(event) {
        this.customerObj.firstName = event.target.value;
    }
    readLastName(event) {
        this.customerObj.lastName = event.target.value;
    }
    readPhone(event) {
        this.customerObj.phone = event.target.value;
    }

    handleToggleSection(event) {

    }
    handleSetActiveSection() {
        const accordion = this.template.querySelector('.example-accordion');
        accordion.activeSectionName = 'Account';
    }
    saveAccountOppDataHandler() {
        try {
            console.log('saveAccountOppDataHandler');
            console.log('accountObj:' + JSON.stringify(this.accountObj));
            saveAccountOppData({ accountObj: JSON.stringify(this.accountObj), opportunityObj: JSON.stringify(this.opportunityObj) })
                .then(result => {
                    console.log('result:' + JSON.stringify(result));
                    // this.data_obj = result;  
                    this.error = undefined;
                    window.open('/' + result, '_self');
                })
                .catch(error => {
                    this.error = error;
                    let message = 'Unknown error';
                    if (Array.isArray(error.body)) {
                        message = error.body.map(e => e.message).join(', ');
                    } else if (typeof error.body.message === 'string') {
                        message = error.body.message;
                    }
                    console.log(message);
                    const evt = new ShowToastEvent({
                        title: 'ERROR',
                        message: message,
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(evt);
                    this.dataObj = undefined;
                    console.log('error setting default', error);
                });
        } catch (err) {
            console.log(err.stack);
        }
    }
}